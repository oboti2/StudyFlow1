# StudyFlow — CS50 Study Planner

A responsive, static study dashboard for CS50x, built with **HTML, CSS, and vanilla JavaScript**. No framework, build step, backend, or database required.

## Run it
1. Download and unzip the project.
2. Open `index.html` in a modern browser.
3. That's it. For the most reliable local experience, you can also serve the folder with a simple static server (for example, VS Code Live Server).

## Features
- CS50-inspired overview dashboard with study stats and course progress
- Add tasks with category, due date, and priority
- Mark tasks complete and delete tasks
- Filter tasks by all, in-progress, and completed
- Weekly schedule with previous/next week navigation
- Add study sessions to a selected day
- Update course progress
- Light/dark theme toggle
- Responsive sidebar for mobile
- Saves task, schedule, progress, and theme preferences in browser `localStorage`

## Project structure
```text
cs50-studyflow/
├── index.html
├── css/
│   └── styles.css
├── js/
│   └── app.js
└── README.md
```

## Notes
- This is a front-end demo: the initial metrics and sample schedule are illustrative, not connected to a real CS50 account.
- Data is stored only in the current browser on the current device. Clearing site data resets it.
- The optional Google Fonts import needs an internet connection; system fallback fonts are included.
