const $ = (selector, root = document) => root.querySelector(selector);
const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];
const STORAGE_KEY = "studyflow-cs50-v1";
const today = new Date();
const isoDate = (date) => `${date.getFullYear()}-${String(date.getMonth()+1).padStart(2,"0")}-${String(date.getDate()).padStart(2,"0")}`;
const addDays = (date, days) => { const d = new Date(date); d.setDate(d.getDate()+days); return d; };
const prettyDate = (date, options = {month:"short",day:"numeric"}) => date.toLocaleDateString(undefined, options);
const safeId = () => `${Date.now()}-${Math.random().toString(16).slice(2,8)}`;

const seedTasks = [
  {id:"t1",title:"Watch Week 4 lecture: Algorithms",category:"Lecture",due:isoDate(today),priority:"High",done:false},
  {id:"t2",title:"Review merge sort & big O notation",category:"Reading",due:isoDate(today),priority:"Medium",done:false},
  {id:"t3",title:"Complete Problem Set 3 practice",category:"Problem Set",due:isoDate(today),priority:"High",done:false},
  {id:"t4",title:"Solve 3 algorithm practice questions",category:"Practice",due:isoDate(today),priority:"Low",done:false}
];
const seedSessions = [
  {id:"s1",day:0,time:"09:00",duration:60,title:"Watch lecture: Algorithms",color:"purple"},
  {id:"s2",day:0,time:"11:00",duration:45,title:"Review lecture notes",color:"green"},
  {id:"s3",day:0,time:"16:00",duration:60,title:"Problem set practice",color:"orange"},
  {id:"s4",day:1,time:"10:00",duration:60,title:"Big O notation",color:"purple"},
  {id:"s5",day:2,time:"14:00",duration:90,title:"Problem Set 3",color:"orange"},
  {id:"s6",day:3,time:"09:30",duration:45,title:"Recursion practice",color:"green"},
  {id:"s7",day:4,time:"13:00",duration:60,title:"Review & quiz",color:"purple"},
  {id:"s8",day:5,time:"10:00",duration:90,title:"Catch-up study block",color:"green"}
];
function loadState(){
  try { const saved = JSON.parse(localStorage.getItem(STORAGE_KEY)); if(saved) return {...saved,tasks:Array.isArray(saved.tasks)?saved.tasks:seedTasks,sessions:Array.isArray(saved.sessions)?saved.sessions:seedSessions}; } catch(e) {}
  const monday = new Date(today); monday.setHours(0,0,0,0); monday.setDate(monday.getDate() - ((monday.getDay()+6)%7));
  return {tasks:seedTasks,sessions:seedSessions,courseProgress:35,weekStart:isoDate(monday),selectedDate:isoDate(today),theme:"light",studyHours:6.5,streak:5};
}
let state = loadState();
let activeFilter = "all";
let editingTaskId = null;
let toastTimer;
function saveState(){ try { localStorage.setItem(STORAGE_KEY,JSON.stringify(state)); } catch(e) {} }
function escapeHTML(value){return String(value).replace(/[&<>"']/g, c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));}
function formatTime(time){const [h,m]=time.split(":").map(Number);return `${h%12||12}:${String(m).padStart(2,"0")} ${h>=12?"PM":"AM"}`;}
function formatDuration(minutes){return minutes>=60?`${minutes/60===1?"1 hour":`${minutes/60} hours`}`:`${minutes} min`;}
function toast(message){const el=$("#toast");el.textContent=message;el.classList.add("show");clearTimeout(toastTimer);toastTimer=setTimeout(()=>el.classList.remove("show"),2600);}
function updateDateLabel(){ $("#todayLabel").textContent=today.toLocaleDateString(undefined,{weekday:"long",month:"long",day:"numeric"}).toUpperCase(); }
function updateStats(){
  const done=state.tasks.filter(t=>t.done).length, total=state.tasks.length, pct=total?Math.round(done/total*100):0;
  $("#completedStat").textContent=8+done; $("#totalStat").textContent=12+state.tasks.length;
  $("#taskProgressBar").style.width=`${Math.min(100,Math.round((8+done)/(12+state.tasks.length)*100))}%`;
  $("#taskProgressText").textContent=`${Math.round((8+done)/(12+state.tasks.length)*100)}%`;
  $("#navTaskCount").textContent=state.tasks.filter(t=>!t.done).length;
  $("#headingTaskCount").textContent=state.tasks.filter(t=>!t.done).length;
  $("#studyHours").textContent=(state.studyHours + done*.5).toFixed(1);
  $("#courseProgress").textContent=state.courseProgress;
  $("#courseProgressBar").style.width=`${state.courseProgress}%`;
  $("#donutPercent").textContent=`${state.courseProgress}%`;
  $("#courseDonut").style.background=`conic-gradient(var(--purple) 0 ${state.courseProgress}%, #eeedf6 ${state.courseProgress}% 100%)`;
  $("#streakCount").textContent=state.streak;
}
function renderTasks(){
  const list=$("#taskList");
  const tasks=state.tasks.filter(t=>activeFilter==="all"||(activeFilter==="active"&&!t.done)||(activeFilter==="done"&&t.done));
  if(!tasks.length){list.innerHTML=`<div class="empty-state">${activeFilter==="done"?"No completed tasks yet. Start checking things off!":"You're all caught up. Add a task to keep moving."}</div>`;return;}
  list.innerHTML=tasks.map(task=>{
    const categoryClass=task.category.toLowerCase().replace(/\s+/g,"-");
    const due=task.due?prettyDate(new Date(`${task.due}T12:00:00`),{month:"short",day:"numeric"}):"No due date";
    return `<div class="task-row ${task.done?"is-done":""}" data-id="${escapeHTML(task.id)}">
      <input class="task-check" type="checkbox" aria-label="Mark ${escapeHTML(task.title)} complete" ${task.done?"checked":""} data-action="toggle">
      <div class="task-copy"><div class="task-title">${escapeHTML(task.title)}</div><div class="task-meta"><span class="category-dot ${categoryClass}"></span>${escapeHTML(task.category)} <span>·</span> ${escapeHTML(due)}</div></div>
      <span class="priority ${task.priority.toLowerCase()}">${escapeHTML(task.priority)}</span>
      <button class="task-delete" data-action="delete" aria-label="Delete ${escapeHTML(task.title)}" title="Delete task">×</button>
    </div>`;
  }).join("");
}
function weekStartDate(){return new Date(`${state.weekStart}T12:00:00`);}
function renderWeek(){
  const start=weekStartDate(), selected=new Date(`${state.selectedDate}T12:00:00`);
  $("#weekStrip").innerHTML=Array.from({length:7},(_,i)=>{
    const d=addDays(start,i), date=isoDate(d), has=state.sessions.some(s=>s.day===i);
    return `<button class="day-button ${date===state.selectedDate?"selected":""} ${has?"has-session":""}" data-date="${date}" aria-label="${d.toLocaleDateString(undefined,{weekday:"long",month:"long",day:"numeric"})}"><span class="day-name">${d.toLocaleDateString(undefined,{weekday:"short"}).toUpperCase()}</span><span class="day-number">${d.getDate()}</span><i class="day-indicator"></i></button>`;
  }).join("");
  $("#selectedDayLabel").textContent=`${selected.toLocaleDateString(undefined,{weekday:"long"})}'s plan`;
  const dayIndex=Math.round((selected-start)/86400000);
  const sessions=state.sessions.filter(s=>s.day===dayIndex).sort((a,b)=>a.time.localeCompare(b.time));
  $("#sessionCount").textContent=`${sessions.length} ${sessions.length===1?"session":"sessions"}`;
  $("#sessionList").innerHTML=sessions.length?sessions.map(s=>`<div class="session-row"><span class="session-time">${formatTime(s.time)}</span><i class="session-bar ${s.color==="green"?"green-bar":s.color==="orange"?"orange-bar":""}"></i><div class="session-info"><strong>${escapeHTML(s.title)}</strong><small>CS50x · Focus session</small></div><span class="session-duration">${formatDuration(s.duration)}</span></div>`).join(""):`<div class="empty-state">No sessions planned for this day. Give your future self a plan.</div>`;
}
function render(){updateDateLabel();updateStats();renderTasks();renderWeek();}
function openTaskDialog(task=null){
  editingTaskId=task?.id||null;$("#taskDialogTitle").textContent=task?"Edit task":"Add a task";
  $("#taskTitle").value=task?.title||"";$("#taskCategory").value=task?.category||"Lecture";
  $("#taskDue").value=task?.due||isoDate(today);$("#taskPriority").value=task?.priority||"Medium";$("#taskId").value=task?.id||"";
  $("#taskDialog").showModal();setTimeout(()=>$("#taskTitle").focus(),50);
}
function closeDialog(id){const d=document.getElementById(id);if(d?.open)d.close();}
$("#taskForm").addEventListener("submit",e=>{
  e.preventDefault();const title=$("#taskTitle").value.trim();if(!title)return;
  const task={id:editingTaskId||safeId(),title,category:$("#taskCategory").value,due:$("#taskDue").value,priority:$("#taskPriority").value,done:editingTaskId?!!state.tasks.find(t=>t.id===editingTaskId)?.done:false};
  if(editingTaskId){state.tasks=state.tasks.map(t=>t.id===editingTaskId?task:t);toast("Task updated.");}else{state.tasks.unshift(task);toast("Task added to your list.");}
  saveState();render();closeDialog("taskDialog");
});
$("#taskList").addEventListener("change",e=>{
  if(!e.target.matches('[data-action="toggle"]'))return;
  const row=e.target.closest(".task-row"),task=state.tasks.find(t=>t.id===row.dataset.id);if(!task)return;
  task.done=e.target.checked;if(task.done){state.studyHours=Math.round((state.studyHours+.25)*100)/100;toast("Nice work — task completed!");}saveState();render();
});
$("#taskList").addEventListener("click",e=>{
  const action=e.target.closest("[data-action]")?.dataset.action;if(!action)return;
  const row=e.target.closest(".task-row"),id=row?.dataset.id;if(!id)return;
  if(action==="delete"){state.tasks=state.tasks.filter(t=>t.id!==id);saveState();render();toast("Task deleted.");}
  if(action==="edit"){const task=state.tasks.find(t=>t.id===id);if(task)openTaskDialog(task);}
});
$$(".filter-chip").forEach(btn=>btn.addEventListener("click",()=>{activeFilter=btn.dataset.filter;$$(".filter-chip").forEach(b=>b.classList.toggle("selected",b===btn));renderTasks();}));
$("#viewAllTasks").addEventListener("click",()=>{$(".filter-chip[data-filter='all']").click();$("#tasks").scrollIntoView({behavior:"smooth",block:"start"});});
["#addTaskTop","#addTaskInline"].forEach(sel=>$(sel).addEventListener("click",()=>openTaskDialog()));
$("#weekStrip").addEventListener("click",e=>{
  const btn=e.target.closest("[data-date]");if(!btn)return;state.selectedDate=btn.dataset.date;saveState();renderWeek();
});
function shiftWeek(amount){const start=addDays(weekStartDate(),amount*7);state.weekStart=isoDate(start);state.selectedDate=isoDate(start);saveState();renderWeek();}
$("#weekBack").addEventListener("click",()=>shiftWeek(-1));$("#weekForward").addEventListener("click",()=>shiftWeek(1));
$("#addSessionButton").addEventListener("click",()=>{$("#sessionTitle").value="";$("#sessionTime").value="16:00";$("#sessionDialog").showModal();});
$("#sessionForm").addEventListener("submit",e=>{
  e.preventDefault();const title=$("#sessionTitle").value.trim();if(!title)return;
  const start=weekStartDate(),selected=new Date(`${state.selectedDate}T12:00:00`),day=Math.round((selected-start)/86400000);
  const colors=["purple","green","orange"];state.sessions.push({id:safeId(),day,time:$("#sessionTime").value,duration:Number($("#sessionDuration").value),title,color:colors[state.sessions.length%colors.length]});
  saveState();renderWeek();closeDialog("sessionDialog");toast("Study session added.");
});
$("#updateProgress").addEventListener("click",()=>{$("#progressRange").value=state.courseProgress;$("#progressRangeValue").textContent=`${state.courseProgress}%` ;$("#progressDialog").showModal();});
$("#progressRange").addEventListener("input",e=>$("#progressRangeValue").textContent=`${e.target.value}%`);
$("#progressForm").addEventListener("submit",e=>{e.preventDefault();state.courseProgress=Number($("#progressRange").value);saveState();updateStats();closeDialog("progressDialog");toast("Course progress updated.");});
$$("[data-close]").forEach(btn=>btn.addEventListener("click",()=>closeDialog(btn.dataset.close)));
$$("dialog").forEach(dialog=>dialog.addEventListener("click",e=>{if(e.target===dialog)dialog.close();}));
$("#themeToggle").addEventListener("click",()=>{document.body.classList.toggle("dark");state.theme=document.body.classList.contains("dark")?"dark":"light";saveState();});
$("#menuButton").addEventListener("click",()=>$("#sidebar").classList.toggle("open"));
$$(".nav-link").forEach(link=>link.addEventListener("click",()=>{$$(".nav-link").forEach(a=>a.classList.toggle("active",a===link));$("#sidebar").classList.remove("open");}));
$("#profileButton").addEventListener("click",()=>toast("You're doing great. Keep learning at your own pace!"));
document.addEventListener("keydown",e=>{if(e.key==="Escape")$("#sidebar").classList.remove("open");});
if(state.theme==="dark")document.body.classList.add("dark");
render();
